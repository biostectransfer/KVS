﻿function openRadWindowZulPos() {
    $find("MainContentPlaceHolder_ZulassungNachbearbeitunguserControl_RadWindowZul_Product").show();
}
function openRadWindowZulNeuzulassungPos() {
    $find("MainContentPlaceHolder_ZulassungsstelleuserControl_RadWindowZul_Product").show();
}

  